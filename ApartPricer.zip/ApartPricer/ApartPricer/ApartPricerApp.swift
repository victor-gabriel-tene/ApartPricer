//
//  ApartPricerApp.swift
//  ApartPricer
//
//  Created by Victor Tene on 27.08.2024.
//

import SwiftUI

@main
struct ApartPricerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
