//
//  ContentView.swift
//  ApartPricer
//
//  Created by Victor Tene on 27.08.2024.
//

import CoreML
import SwiftUI

struct ContentView: View {
    @State private var roomCount = 1
    @State private var area = 60.0
    @State private var floor = 0
    @State private var floorCount = 8
    @State private var district = 1
    @State private var score = 3
    
    @State private var message = "Apartment Price"
    @State private var price = 65_785.3
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Apartment's data") {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Number of rooms")
                            .font(.headline)
                        Stepper("^[\(roomCount) room](inflect: true)", value: $roomCount, in: 1...7)
                    }
                    .onChange(of: roomCount, calculatePrice)
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Area")
                            .font(.headline)
                        
                        Stepper("\(area.formatted()) m²", value: $area, in: 10...100, step: 0.5)
                    }
                    .onChange(of: area, calculatePrice)
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Floor")
                            .font(.headline)
                        
                        Stepper("\(floor)/\(floorCount)", value: $floor, in: 0...floorCount)
                    }
                    .onChange(of: floor, calculatePrice)
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Floor Count")
                            .font(.headline)
                        
                        Stepper("\(floorCount)", value: $floorCount, in: 1...12)
                    }
                    .onChange(of: floorCount, calculatePrice)
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("District")
                            .font(.headline)
                        
                        Stepper("\(district)/6", value: $district, in: 1...6)
                    }
                    .onChange(of: district, calculatePrice)
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Score")
                            .font(.headline)
                        
                        Stepper("\(score)/5", value: $score, in: 1...5)
                    }
                    .onChange(of: score, calculatePrice)
                }
            }
            .navigationTitle("ApartPricer")
            
            VStack(alignment: .center) {
                Text(message)
                    .font(.title3.weight(.semibold))
                
                Text(String(format: "%.2f€", price))
                    .font(.title.weight(.heavy))
            }
        }
    }
    
    func calculatePrice() {
        do {
            let config = MLModelConfiguration()
            let model = try Pricer(configuration: config)
            
            let prediction = try model.prediction(roomCount: Int64(roomCount), area: area, floor: Int64(floor), floorCount: Int64(floorCount), district: Int64(district), score: Int64(score))
            
            message = "Apartment Price"
            price = prediction.price
        } catch {
            message = "Error!"
            price = 0.0
        }
    }
}

#Preview {
    ContentView()
}
